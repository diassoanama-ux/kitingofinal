export type Category =
  | 'Todas'
  | 'Peças de Motor'
  | 'Suspensão'
  | 'Eletrónica'
  | 'Pneus'
  | 'Óleos & Lubrificantes'

export const categories: Category[] = [
  'Todas',
  'Peças de Motor',
  'Suspensão',
  'Eletrónica',
  'Pneus',
  'Óleos & Lubrificantes',
]

export type Product = {
  id: string
  name: string
  category: Exclude<Category, 'Todas'>
  compatibility: string
  stall: number
  price: number
  image: string
  inStock: number
}

export const products: Product[] = [
  {
    id: 'vela-ngk-4',
    name: 'Vela de ignição Iridium (kit 4)',
    category: 'Peças de Motor',
    compatibility: 'Toyota Hilux 2018-2023',
    stall: 14,
    price: 18500,
    image: '/products/vela-ignicao.png',
    inStock: 12,
  },
  {
    id: 'amortecedor-dianteiro',
    name: 'Amortecedor dianteiro a gás',
    category: 'Suspensão',
    compatibility: 'Toyota Land Cruiser 2015-2022',
    stall: 7,
    price: 64000,
    image: '/products/amortecedor.png',
    inStock: 4,
  },
  {
    id: 'filtro-oleo',
    name: 'Filtro de óleo de alta filtragem',
    category: 'Peças de Motor',
    compatibility: 'Hyundai Accent 2012-2020',
    stall: 22,
    price: 6500,
    image: '/products/filtro-oleo.png',
    inStock: 30,
  },
  {
    id: 'pneu-at-265',
    name: 'Pneu All-Terrain 265/65 R17',
    category: 'Pneus',
    compatibility: 'Toyota Hilux / Fortuner',
    stall: 3,
    price: 92000,
    image: '/products/pneu.png',
    inStock: 8,
  },
  {
    id: 'oleo-5w30',
    name: 'Óleo sintético 5W-30 (4L)',
    category: 'Óleos & Lubrificantes',
    compatibility: 'Motores a gasolina e diesel',
    stall: 14,
    price: 24900,
    image: '/products/oleo-motor.png',
    inStock: 20,
  },
  {
    id: 'bateria-70ah',
    name: 'Bateria 12V 70Ah selada',
    category: 'Eletrónica',
    compatibility: 'Kia Sportage 2016-2022',
    stall: 31,
    price: 58000,
    image: '/products/bateria.png',
    inStock: 6,
  },
]

export const DELIVERY_FEE = 2500

const aoaFormatter = new Intl.NumberFormat('pt-AO', {
  maximumFractionDigits: 0,
})

export function formatKz(value: number) {
  return `${aoaFormatter.format(value)} Kz`
}
