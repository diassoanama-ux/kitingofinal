import { Clock, Package } from 'lucide-react'
import { formatKz } from '@/lib/products'
import type { Order } from '@/components/checkout-drawer'

export function OrdersView({ orders }: { orders: Order[] }) {
  if (orders.length === 0) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-border bg-card px-6 py-14 text-center">
        <Package className="size-10 text-muted-foreground" aria-hidden="true" />
        <p className="font-semibold">Ainda não tem pedidos</p>
        <p className="max-w-xs text-sm text-muted-foreground text-pretty">
          Quando gerar uma Referência Multicaixa, o seu pedido aparece aqui.
        </p>
      </div>
    )
  }

  return (
    <ul className="flex flex-col gap-3">
      {orders.map((order) => (
        <li key={order.id} className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <p className="font-semibold">Pedido {order.id}</p>
            <span className="flex items-center gap-1 rounded-full bg-accent px-2 py-0.5 text-xs font-medium text-accent-foreground">
              <Clock className="size-3" aria-hidden="true" />
              Aguarda pagamento
            </span>
          </div>
          <dl className="grid grid-cols-3 gap-2 rounded-xl bg-muted p-3 text-xs">
            <div>
              <dt className="text-muted-foreground">Entidade</dt>
              <dd className="font-mono text-sm font-bold">{order.entity}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Referência</dt>
              <dd className="font-mono text-sm font-bold">{order.reference}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Montante</dt>
              <dd className="text-sm font-bold tabular-nums">{formatKz(order.amount)}</dd>
            </div>
          </dl>
          <p className="text-xs text-muted-foreground">
            {order.itemCount} {order.itemCount === 1 ? 'item' : 'itens'} · Recolha na Praça dos Correios
          </p>
        </li>
      ))}
    </ul>
  )
}
