'use client'

import { MapPin, Search, ShoppingCart, X } from 'lucide-react'
import type { Ref } from 'react'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const locations = ['Luanda, Angola', 'Benguela, Angola', 'Huambo, Angola', 'Lubango, Angola']

const searchSuggestions = ['Vela de ignição', 'Amortecedor Toyota', 'Filtro de óleo']

type AppHeaderProps = {
  query: string
  onQueryChange: (value: string) => void
  location: string
  onLocationChange: (value: string) => void
  cartCount: number
  onCartClick: () => void
  searchRef: Ref<HTMLInputElement>
}

export function AppHeader({
  query,
  onQueryChange,
  location,
  onLocationChange,
  cartCount,
  onCartClick,
  searchRef,
}: AppHeaderProps) {
  return (
    <header className="sticky top-0 z-30 bg-primary text-primary-foreground shadow-md">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 pt-4 pb-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div
              aria-hidden="true"
              className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-brand-accent text-lg font-black text-brand-accent-foreground"
            >
              CE
            </div>
            <div className="leading-tight">
              <p className="text-lg font-bold tracking-tight">
                Correios <span className="text-brand-accent">Express</span>
              </p>
              <p className="text-xs text-primary-foreground/70 text-pretty">
                A praça dos correios no seu telemóvel
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onCartClick}
            className="relative flex size-10 shrink-0 items-center justify-center rounded-full bg-primary-foreground/10 transition-colors hover:bg-primary-foreground/20 focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:outline-none"
          >
            <ShoppingCart className="size-5" aria-hidden="true" />
            <span className="sr-only">Abrir carrinho ({cartCount} itens)</span>
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 flex size-5 items-center justify-center rounded-full bg-brand-accent text-[11px] font-bold text-brand-accent-foreground">
                {cartCount}
              </span>
            )}
          </button>
        </div>

        <div className="flex flex-col gap-2 md:flex-row md:items-center">
          <Select value={location} onValueChange={(value) => value && onLocationChange(value)}>
            <SelectTrigger
              aria-label="Localização de entrega"
              className="h-10 w-full border-primary-foreground/15 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/15 md:w-56 [&_svg]:text-primary-foreground/70"
            >
              <MapPin className="size-4 text-brand-accent" aria-hidden="true" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {locations.map((loc) => (
                <SelectItem key={loc} value={loc}>
                  {loc}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <label htmlFor="search-parts" className="sr-only">
              Pesquisar peças auto
            </label>
            <Input
              id="search-parts"
              ref={searchRef}
              type="search"
              value={query}
              onChange={(e) => onQueryChange(e.target.value)}
              placeholder="Vela de ignição, Amortecedor Toyota…"
              className="h-11 rounded-xl border-0 bg-card pr-10 pl-9 text-foreground shadow-sm placeholder:text-muted-foreground"
            />
            {query && (
              <button
                type="button"
                onClick={() => onQueryChange('')}
                className="absolute top-1/2 right-2 flex size-7 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:bg-muted"
              >
                <X className="size-4" aria-hidden="true" />
                <span className="sr-only">Limpar pesquisa</span>
              </button>
            )}
          </div>
        </div>

        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4" aria-label="Pesquisas populares">
          {searchSuggestions.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => onQueryChange(s)}
              className="shrink-0 rounded-full border border-primary-foreground/20 px-3 py-1 text-xs text-primary-foreground/85 transition-colors hover:border-brand-accent hover:text-brand-accent"
            >
              {s}
            </button>
          ))}
        </div>
      </div>
    </header>
  )
}
