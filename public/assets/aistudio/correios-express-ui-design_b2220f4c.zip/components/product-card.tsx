'use client'

import Image from 'next/image'
import { Check, Plus, Store } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatKz, type Product } from '@/lib/products'

type ProductCardProps = {
  product: Product
  quantityInCart: number
  onAdd: (product: Product) => void
}

export function ProductCard({ product, quantityInCart, onAdd }: ProductCardProps) {
  const lowStock = product.inStock <= 5

  return (
    <article className="flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-shadow hover:shadow-md">
      <div className="relative aspect-square bg-muted">
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="(min-width: 1024px) 25vw, (min-width: 768px) 33vw, 50vw"
          className="object-cover"
        />
        {lowStock && (
          <span className="absolute top-2 left-2 rounded-full bg-destructive px-2 py-0.5 text-[10px] font-semibold text-white">
            Só {product.inStock} em stock
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-3">
        <Badge
          variant="secondary"
          className="block h-auto max-w-full justify-start truncate rounded-md py-0.5 text-left bg-accent px-1.5 text-[11px] text-accent-foreground"
        >
          {product.compatibility}
        </Badge>

        <h3 className="line-clamp-2 text-sm leading-snug font-semibold text-balance">{product.name}</h3>

        <p className="flex items-center gap-1 text-[11px] text-muted-foreground">
          <Store className="size-3 shrink-0" aria-hidden="true" />
          <span className="truncate">Banca #{product.stall} - Praça dos Correios</span>
        </p>

        <div className="mt-auto flex flex-col gap-2 pt-1">
          <p className="text-base font-bold tabular-nums">{formatKz(product.price)}</p>
          <Button
            onClick={() => onAdd(product)}
            className="h-9 w-full rounded-lg bg-brand-accent font-semibold text-brand-accent-foreground hover:bg-brand-accent/90"
          >
            {quantityInCart > 0 ? (
              <>
                <Check className="size-4" aria-hidden="true" />
                No carrinho ({quantityInCart})
              </>
            ) : (
              <>
                <Plus className="size-4" aria-hidden="true" />
                Adicionar
              </>
            )}
          </Button>
        </div>
      </div>
    </article>
  )
}
