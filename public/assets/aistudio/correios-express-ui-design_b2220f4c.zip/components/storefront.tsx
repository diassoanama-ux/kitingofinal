'use client'

import { useMemo, useRef, useState } from 'react'
import { ChevronRight, SearchX, ShieldCheck, ShoppingCart } from 'lucide-react'
import { AppHeader } from '@/components/app-header'
import { BottomNav, type Tab } from '@/components/bottom-nav'
import { CategoryPills } from '@/components/category-pills'
import { CheckoutDrawer, type CartLine, type Order } from '@/components/checkout-drawer'
import { OrdersView } from '@/components/orders-view'
import { ProductCard } from '@/components/product-card'
import { formatKz, products, type Category, type Product } from '@/lib/products'

export function Storefront() {
  const [query, setQuery] = useState('')
  const [location, setLocation] = useState('Luanda, Angola')
  const [category, setCategory] = useState<Category>('Todas')
  const [cart, setCart] = useState<Record<string, number>>({})
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [tab, setTab] = useState<Tab>('inicio')
  const [orders, setOrders] = useState<Order[]>([])
  const searchRef = useRef<HTMLInputElement>(null)

  const filtered = useMemo(() => {
    const words = query
      .toLowerCase()
      .normalize('NFD')
      .replace(/\p{Diacritic}/gu, '')
      .split(/\s+/)
      .filter(Boolean)
    return products.filter((p) => {
      if (category !== 'Todas' && p.category !== category) return false
      if (words.length === 0) return true
      const haystack = `${p.name} ${p.compatibility} ${p.category}`
        .toLowerCase()
        .normalize('NFD')
        .replace(/\p{Diacritic}/gu, '')
      return words.some((w) => haystack.includes(w))
    })
  }, [query, category])

  const lines: CartLine[] = products
    .filter((p) => cart[p.id])
    .map((product) => ({ product, quantity: cart[product.id] }))
  const cartCount = lines.reduce((sum, l) => sum + l.quantity, 0)
  const cartTotal = lines.reduce((sum, l) => sum + l.quantity * l.product.price, 0)

  function addToCart(product: Product) {
    setCart((prev) => ({
      ...prev,
      [product.id]: Math.min((prev[product.id] ?? 0) + 1, product.inStock),
    }))
  }

  function updateQuantity(productId: string, quantity: number) {
    setCart((prev) => {
      const next = { ...prev }
      if (quantity <= 0) delete next[productId]
      else next[productId] = quantity
      return next
    })
  }

  function handleOrderCreated(order: Order) {
    setOrders((prev) => [order, ...prev])
    setCart({})
  }

  function handleTabChange(next: Tab) {
    setTab(next)
    if (next === 'pesquisar') {
      window.scrollTo({ top: 0, behavior: 'smooth' })
      searchRef.current?.focus()
    }
  }

  const showOrders = tab === 'pedidos'

  return (
    <div className="min-h-dvh pb-36">
      <AppHeader
        query={query}
        onQueryChange={(value) => {
          setQuery(value)
          if (showOrders) setTab('inicio')
        }}
        location={location}
        onLocationChange={setLocation}
        cartCount={cartCount}
        onCartClick={() => setCheckoutOpen(true)}
        searchRef={searchRef}
      />

      <main className="mx-auto flex max-w-6xl flex-col gap-4 px-4 pt-4">
        {showOrders ? (
          <section aria-labelledby="orders-heading" className="flex flex-col gap-3">
            <h1 id="orders-heading" className="text-xl font-bold">
              Meus Pedidos
            </h1>
            <OrdersView orders={orders} />
          </section>
        ) : (
          <>
            <div className="flex items-center gap-3 rounded-2xl bg-primary/5 p-3 ring-1 ring-primary/10">
              <ShieldCheck className="size-8 shrink-0 text-primary" aria-hidden="true" />
              <p className="text-xs leading-relaxed text-pretty">
                <span className="font-bold">Zero Fiado:</span> pague por Referência Multicaixa e recolha
                com segurança na banca. Entregas em {location.split(',')[0]}.
              </p>
            </div>

            <CategoryPills active={category} onChange={setCategory} />

            <section aria-labelledby="products-heading" className="flex flex-col gap-3">
              <div className="flex items-baseline justify-between">
                <h1 id="products-heading" className="text-lg font-bold">
                  {query ? `Resultados para “${query}”` : category === 'Todas' ? 'Peças em destaque' : category}
                </h1>
                <span className="text-xs text-muted-foreground">
                  {filtered.length} {filtered.length === 1 ? 'peça' : 'peças'}
                </span>
              </div>

              {filtered.length === 0 ? (
                <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-border bg-card px-6 py-12 text-center">
                  <SearchX className="size-8 text-muted-foreground" aria-hidden="true" />
                  <p className="font-semibold">Nenhuma peça encontrada</p>
                  <p className="text-sm text-muted-foreground">Tente outro termo ou categoria.</p>
                </div>
              ) : (
                <ul className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
                  {filtered.map((product) => (
                    <li key={product.id} className="flex">
                      <ProductCard
                        product={product}
                        quantityInCart={cart[product.id] ?? 0}
                        onAdd={addToCart}
                      />
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>

      {cartCount > 0 && !checkoutOpen && (
        <div className="fixed inset-x-0 bottom-[calc(4rem+env(safe-area-inset-bottom))] z-20 px-4 pb-2">
          <button
            type="button"
            onClick={() => setCheckoutOpen(true)}
            className="mx-auto flex w-full max-w-md items-center gap-3 rounded-2xl bg-primary px-4 py-3 text-primary-foreground shadow-lg transition-transform active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-brand-accent focus-visible:outline-none"
          >
            <span className="flex size-9 items-center justify-center rounded-xl bg-brand-accent text-brand-accent-foreground">
              <ShoppingCart className="size-4" aria-hidden="true" />
            </span>
            <span className="flex-1 text-left">
              <span className="block text-xs text-primary-foreground/70">
                {cartCount} {cartCount === 1 ? 'item' : 'itens'} no carrinho
              </span>
              <span className="block font-bold tabular-nums">{formatKz(cartTotal)}</span>
            </span>
            <span className="flex items-center gap-1 text-sm font-semibold">
              Finalizar
              <ChevronRight className="size-4" aria-hidden="true" />
            </span>
          </button>
        </div>
      )}

      <BottomNav active={tab} onChange={handleTabChange} pendingOrders={orders.length} />

      <CheckoutDrawer
        open={checkoutOpen}
        onOpenChange={setCheckoutOpen}
        lines={lines}
        onQuantityChange={updateQuantity}
        onOrderCreated={handleOrderCreated}
      />
    </div>
  )
}
